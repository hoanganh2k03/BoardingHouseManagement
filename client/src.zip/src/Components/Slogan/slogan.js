function Slogan() {
  return (
    <div style={{ display: "flex", marginTop: "20px" }} className="Slogan">
      <span
        style={{
          color: "#E13427",
          textAlign: "center",
          display: "flex",
          margin: "-50px auto",
          fontSize: "25px",
          fontWeight: "700",
        }}
      >
        Phongtro123.com
      </span>
    </div>
  );
}

export default Slogan;
