import Posts from "./Posts/posts";
import Search from "./Search/search";
import "./body.css";
import Page from "./Page/main";
function Body() {
  return (
    <div className="Body">
      <Posts />
      
      {/* <Page /> */}
    </div>
  );
}

export default Body;
