import React from "react";
import "../Posts/post.css"; // Import CSS file for styling
import Main_Posts from "../Posts/Main_posts/image_des";

function Posts() {
  return (
    <div className="container">
      <Main_Posts />
    </div>
  );
}

export default Posts;
